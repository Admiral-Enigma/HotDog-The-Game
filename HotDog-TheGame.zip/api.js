GJAPI.game_id = 96964;
GJAPI.private_key = 'fa47db1118d5027e8d60999be1a09ee6';
